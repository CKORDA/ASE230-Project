<?php die() 
?>signater1@nku.edu;$2y$10$1la4yzWYOMIZKDcXSHbrouwDn1UbI/yblMvzob87Xcw4fL5nuut9C
signater1@nku.edu;$2y$10$SEOUjYd0DxSgMUiZRWLePu6MQ0yatoX0dhedjHKyPt04EJjrWiqQC
signater1@nku.edu;$2y$10$CQ6WrvuGvSaWSIM7ToGLB.Bg8Aau137aKFbHLERlg7Zj9pJKhorG6
signater1@nku.edu;$2y$10$JjUc2DgmUx6TxY1p9Z1DN.wAW6IpEuJWhYbnBLdxtLj.gspDv.IDy
signater1@nku.edu;$2y$10$CmB5uBiirFtRWh5NMLAAEeNx0x4LkbEzFpu0Giuf/rX823MkuxZSO
signater1@nku.edu;$2y$10$c5Gckt/CaCHKFpNz/8qTEOxihCLm/Wsx6KlNGZFkSWrekpZUxro5q
